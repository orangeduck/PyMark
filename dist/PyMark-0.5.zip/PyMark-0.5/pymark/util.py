
def flags(num): return [i for i in range(0, num)]
def enum(num): return [2**i for i in range(0, num)]
def module(**kwargs): return kwargs 
def properties(**kwargs): return kwargs
def modifiers(*args): return args
